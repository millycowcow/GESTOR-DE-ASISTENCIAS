/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nombre;

/**
 *
 * @author losro
 */
public class ListaAlunosTurismo {
    Alumno[] a = new Alumno[33];

    public ListaAlunosTurismo() {
        a[0] = new Alumno("GABRIELA HERNANDEZ RUIZ","Turismo","23TE001234","abcd5678XYZ432109", 20, 60);
        a[1] = new Alumno("PEDRO LOPEZ MARTINEZ","Turismo","23TE002345","efgh7890ABC109876", 30, 50);
        a[2] = new Alumno("ISABEL GOMEZ SANCHEZ","Turismo","23TE003456","ijkl1234DEF987543", 15, 65);
        a[3] = new Alumno("MIGUEL FLORES GARCIA","Turismo","23TE004567","mnop3456GHI876432", 40, 40);
        a[4] = new Alumno("ANDREA PEREZ HERNANDEZ","Turismo","23TE005678","qrst5678JKL543210", 25, 55);
        a[5] = new Alumno("RAUL MARTINEZ RIVERA","Turismo","23TE006789","uvwx7890MNO321098", 10, 70);
        a[6] = new Alumno("SILVIA LOPEZ GUTIERREZ","Turismo","23TE007890","yzab3456PQR109876", 35, 45);
        a[7] = new Alumno("JORGE RAMIREZ RUIZ","Turismo","23TE008901","cdef5678STU543210", 20, 60);
        a[8] = new Alumno("PATRICIA GUTIERREZ FLORES","Turismo","23TE009012","ghij7890VWX987123", 40, 40);
        a[9] = new Alumno("ALBERTO HERNANDEZ PEREZ","Turismo","23TE010123","klmn1234YZA876543", 15, 65);
        a[10] = new Alumno("ELENA LOPEZ SANCHEZ","Turismo","23TE011234","mnop3456BCD765432", 30, 50);
        a[11] = new Alumno("CARLOS MARTINEZ RIVERA","Turismo","23TE012345","qrst5678EFG109876", 25, 55);
        a[12] = new Alumno("SANDRA GARCIA LOPEZ","Turismo","23TE013456","uvwx7890HIJ321098", 10, 70);
        a[13] = new Alumno("VICTORIA RIVERA HERNANDEZ","Turismo","23TE014567","yzab3456KLM543210", 35, 45);
        a[14] = new Alumno("FERNANDO PEREZ MARTINEZ","Turismo","23TE015678","cdef5678NOP987123", 20, 60);
        a[15] = new Alumno("MARGARITA LOPEZ RAMIREZ","Turismo","23TE016789","ghij7890QRS765432", 40, 40);
        a[16] = new Alumno("ALEJANDRO GUTIERREZ FLORES","Turismo","23TE017890","klmn1234TUV109876", 15, 65);
        a[17] = new Alumno("MARIA HERNANDEZ PEREZ","Turismo","23TE018901","mnop3456WXY321098", 30, 50);
        a[18] = new Alumno("JUAN LOPEZ SANCHEZ","Turismo","23TE019012","qrst5678ZAB543210", 25, 55);
        a[19] = new Alumno("LUCIA MARTINEZ RIVERA","Turismo","23TE020123","uvwx7890CDE987123", 10, 70);
        a[20] = new Alumno("ANGEL GARCIA LOPEZ","Turismo","23TE021234","yzab3456FGH876543", 35, 45);
        a[21] = new Alumno("MONICA RIVERA HERNANDEZ","Turismo","23TE022345","cdef5678IJK109876", 20, 60);
        a[22] = new Alumno("ROBERTO PEREZ MARTINEZ","Turismo","23TE023456","ghij7890LMN321098", 40, 40);
        a[23] = new Alumno("ALEJANDRA LOPEZ RAMIREZ","Turismo","23TE024567","klmn1234OPQ543210", 15, 65);
        a[24] = new Alumno("JAVIER GUTIERREZ FLORES","Turismo","23TE025678","mnop3456RST987123", 30, 50);
        a[25] = new Alumno("CECILIA HERNANDEZ PEREZ","Turismo","23TE026789","qrst5678UVW765432", 25, 55);
        a[26] = new Alumno("MARIO LOPEZ SANCHEZ","Turismo","23TE027890","uvwx7890XYZ109876", 10, 70);
        a[27] = new Alumno("LUZ MARTINEZ RIVERA","Turismo","23TE028901","yzab3456ABC321098", 35, 45);
        a[28] = new Alumno("CRISTINA GARCIA LOPEZ","Turismo","23TE029012","cdef5678DEF543210", 20, 60);
        a[29] = new Alumno("RAFAEL RIVERA HERNANDEZ","Turismo","23TE030123","ghij7890GHI987123", 40, 40);
        a[30] = new Alumno("ISIDRO PEREZ MARTINEZ","Turismo","23TE031234","klmn1234JKL876543", 15, 65);
        a[31] = new Alumno("PAOLA LOPEZ RAMIREZ","Turismo","23TE032345","mnop3456MNO109876", 30, 50);
        a[32] = new Alumno("ADRIAN GUTIERREZ FLORES","Turismo","23TE033456","qrst5678PQR321098", 25, 55);  
    }

    public Alumno[] getA() {
        return a;
    }

    public void setA(Alumno[] a) {
        this.a = a;
    }
      
}
