/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nombre;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;

/**
 *
 * @author losro
 */
public class Reportes {

    public Reportes() {
    }
    
    public void generar_reportes(Alumno[] a, String carrera) throws IOException{
        Date fechaActual = new Date();
        SimpleDateFormat formato = new SimpleDateFormat("dd 'de' MMMM 'de' yyyy"); // Formato: 25 de enero de 2024
        String fechaFormateada = formato.format(fechaActual);
        
        for(int i=0; i<a.length-1; i++){
            int s=a[i].getAsistencias()-a[i].getInasistencias();
            if(s<1){
                try (FileWriter File = new FileWriter("C:/Users/losro/Documents/NetBeansProjects/Nombre/"+carrera+"/"+a[i].getNombre()+".txt")) {
                    File.write("Estudiante: "+a[i].getNombre()+"\n");
                    File.write("Carrera: "+a[i].getCarrera()+"\n");
                    File.write("Fecha: "+fechaFormateada+"\n");
                    File.write("\n");
                    File.write("El presente informe tiene como objetivo documentar las inasistencias recurrentes del"+"\n");
                    File.write("estudiante "+a[i].getNombre()+", matriculado en la carrera de "+a[i].getCarrera()+"\n");
                    File.write("A pesar de las diversas acciones realizadas para abordar esta situación,"+"\n");
                    File.write("el alumno continúa sin asistir a clases de manera regular. "+"\n");
                    File.write("\n");
                    File.write("Detalle de las Inasistencias: "+"\n");
                    File.write("Número total de clases: "+80+"\n");
                    File.write("Número de inasistencias: "+a[i].getInasistencias()+"\n");
                    int x =(a[i].getAsistencias()*100)/80;
                    File.write("Porcentaje de asistencia:  "+x+"% "+"\n");   
                }
            }
        }
        JOptionPane.showInternalMessageDialog(null,"Archivo guardado en la ruta: C:/Users/losro/Documents/NetBeansProjects/Nombre/"+carrera);
        
    }
}
