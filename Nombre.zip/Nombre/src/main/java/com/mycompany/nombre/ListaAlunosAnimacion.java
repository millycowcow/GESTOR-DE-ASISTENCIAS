/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nombre;

/**
 *
 * @author losro
 */
public class ListaAlunosAnimacion {
    Alumno[] a = new Alumno[33];

    public ListaAlunosAnimacion () {
        a[0] = new Alumno("ANDREA MORALES LOPEZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE001234","zxcv5678QAZ123456", 30, 50);
        a[1] = new Alumno("JUAN GARCIA PEREZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE002345","sdfg7890WSX987654", 35, 45);
        a[2] = new Alumno("LUCIA MARTINEZ RAMIREZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE003456","cvbn1234EDC654321", 40, 40);
        a[3] = new Alumno("MARIO LOPEZ GOMEZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE004567","wert3456RFV321098", 28, 52);
        a[4] = new Alumno("NATALIA HERNANDEZ SANCHEZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE005678","tyui5678TGB543210", 38, 42);
        a[5] = new Alumno("VICTORIA FLORES CASTILLO","Ingenieria en Animacion Digital y Efectos Visuales","23TE006789","bnmq7890YHN098765", 37, 43);
        a[6] = new Alumno("FRANCISCO GUTIERREZ RIVERA","Ingenieria en Animacion Digital y Efectos Visuales","23TE007890","mnbv3456UJM321098", 25, 55);
        a[7] = new Alumno("SUSANA PEREZ GARCIA","Ingenieria en Animacion Digital y Efectos Visuales","23TE008901","asdf1234IKL765432", 34, 46);
        a[8] = new Alumno("OSCAR RAMIREZ LOPEZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE009012","dfgh5678OLP987123", 32, 48);
        a[9] = new Alumno("ELENA RODRIGUEZ MARTINEZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE010123","ghjk7890ZXC543210", 30, 50);
        a[10] = new Alumno("CARLOS LOPEZ SANCHEZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE011234","hjkl3456VBN876543", 36, 44);
        a[11] = new Alumno("MARIA FERNANDEZ RAMIREZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE012345","jklz6789NMU987123", 31, 49);
        a[12] = new Alumno("LUIS GOMEZ FLORES","Ingenieria en Animacion Digital y Efectos Visuales","23TE013456","lkjb3456QAZ098765", 29, 51);
        a[13] = new Alumno("FERNANDA SANCHEZ CASTILLO","Ingenieria en Animacion Digital y Efectos Visuales","23TE014567","poi9876WSX543210", 38, 42);
        a[14] = new Alumno("DAVID RIVERA LOPEZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE015678","oiuy1234EDC765432", 26, 54);
        a[15] = new Alumno("CARMEN MORALES HERNANDEZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE016789","plmn4567RFV876543", 33, 47);
        a[16] = new Alumno("JAVIER HERNANDEZ GUTIERREZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE017890","qwex7890TGB987321", 25, 55);
        a[17] = new Alumno("ANGELA RAMIREZ FLORES","Ingenieria en Animacion Digital y Efectos Visuales","23TE018901","wert4567YHN098765", 36, 44);
        a[18] = new Alumno("JORGE LOPEZ MARTINEZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE019012","uioz3456UJM543210", 30, 50);
        a[19] = new Alumno("MONICA PEREZ SANCHEZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE020123","iops6789IKL876543", 35, 45);
        a[20] = new Alumno("ROBERTO HERNANDEZ GOMEZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE021234","zxcv1234OLP987123", 37, 43);
        a[21] = new Alumno("PAULA RAMIREZ FLORES","Ingenieria en Animacion Digital y Efectos Visuales","23TE022345","qwer5678ZXC543210", 32, 48);
        a[22] = new Alumno("MIGUEL GUTIERREZ LOPEZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE023456","asdf7890VBN876543", 25, 55);
        a[23] = new Alumno("ALICIA FERNANDEZ PEREZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE024567","sdfg1234NMU987321", 28, 52);
        a[24] = new Alumno("ALBERTO LOPEZ HERNANDEZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE025678","dfgh3456QAZ098765", 34, 46);
        a[25] = new Alumno("PATRICIA MARTINEZ FLORES","Ingenieria en Animacion Digital y Efectos Visuales","23TE026789","fghj5678WSX543210", 29, 51);
        a[26] = new Alumno("DIEGO GOMEZ PEREZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE027890","ghjk7890EDC765432", 36, 44);
        a[27] = new Alumno("LAURA LOPEZ CASTILLO","Ingenieria en Animacion Digital y Efectos Visuales","23TE028901","hjkl1234RFV876543", 31, 49);
        a[28] = new Alumno("RICARDO HERNANDEZ GOMEZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE029012","jklm4567TGB987321", 32, 48);
        a[29] = new Alumno("VERONICA FERNANDEZ LOPEZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE030123","klmn6789YHN098765", 30, 50);
        a[30] = new Alumno("GUSTAVO SANCHEZ MORALES","Ingenieria en Animacion Digital y Efectos Visuales","23TE031234","lmnb7890UJM543210", 28, 52);
        a[31] = new Alumno("LOURDES RAMIREZ GUTIERREZ","Ingenieria en Animacion Digital y Efectos Visuales","23TE032345","mnvc3456IKL876543", 27, 53);
        a[32] = new Alumno("HUGO FLORES GARCIA","Ingenieria en Animacion Digital y Efectos Visuales","23TE033456","nbvc5678OLP987123", 41, 39);  
    }

    public Alumno[] getA() {
        return a;
    }

    public void setA(Alumno[] a) {
        this.a = a;
    }
      
}
