/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nombre;

/**
 *
 * @author losro
 */
public class ListaAlunosIndustrial {
    Alumno[] a = new Alumno[33];

    public ListaAlunosIndustrial() {
        a[0] = new Alumno("RAUL GOMEZ MARTINEZ","Ingenieria Industrial","23TE001234","fghi1234RST987654", 34, 46);
        a[1] = new Alumno("CARMEN LOPEZ FERNANDEZ","Ingenieria Industrial","23TE002345","jklm5678UVW321098", 38, 42);
        a[2] = new Alumno("LUCAS PEREZ GONZALEZ","Ingenieria Industrial","23TE003456","mnop9101XYZ654321", 27, 53);
        a[3] = new Alumno("CLARA SANCHEZ RAMIREZ","Ingenieria Industrial","23TE004567","qrst1121ABC987123", 29, 51);
        a[4] = new Alumno("DANIELA GARCIA LOPEZ","Ingenieria Industrial","23TE005678","uvwx3141DEF345678", 41, 39);
        a[5] = new Alumno("VICTOR MORALES HERNANDEZ","Ingenieria Industrial","23TE006789","yzab5161GHI432109", 36, 44);
        a[6] = new Alumno("ANDRES MARTINEZ SANCHEZ","Ingenieria Industrial","23TE007890","cdef7181JKL789012", 49, 31);
        a[7] = new Alumno("FABIOLA LOPEZ GOMEZ","Ingenieria Industrial","23TE008901","ghij9202MNO654987", 30, 50);
        a[8] = new Alumno("PABLO RIVERA HERNANDEZ","Ingenieria Industrial","23TE009012","klmn1234PQR321765", 47, 33);
        a[9] = new Alumno("ALICIA MARTINEZ FERNANDEZ","Ingenieria Industrial","23TE010123","mnop5678STU109876", 28, 52);
        a[10] = new Alumno("GERARDO PEREZ SANCHEZ","Ingenieria Industrial","23TE011234","qrst9101VWX987543", 33, 47);
        a[11] = new Alumno("JULIETA LOPEZ MARTINEZ","Ingenieria Industrial","23TE012345","uvwx1121YZA876432", 35, 45);
        a[12] = new Alumno("RAMON GOMEZ FERNANDEZ","Ingenieria Industrial","23TE013456","yzab3141BCD543109", 29, 51);
        a[13] = new Alumno("INES PEREZ RAMIREZ","Ingenieria Industrial","23TE014567","cdef5161EFG876210", 38, 42);
        a[14] = new Alumno("CARLOS MARTINEZ LOPEZ","Ingenieria Industrial","23TE015678","ghij7181HIJ098765", 27, 53);
        a[15] = new Alumno("SOFIA LOPEZ GONZALEZ","Ingenieria Industrial","23TE016789","klmn9202KLM987654", 41, 39);
        a[16] = new Alumno("FERNANDO SANCHEZ HERNANDEZ","Ingenieria Industrial","23TE017890","mnop1234NOP654321", 34, 46);
        a[17] = new Alumno("ANA MARIA RIVERA GOMEZ","Ingenieria Industrial","23TE018901","qrst5678QRS321098", 32, 48);
        a[18] = new Alumno("SERGIO LOPEZ MARTINEZ","Ingenieria Industrial","23TE019012","uvwx9101TUV987654", 35, 45);
        a[19] = new Alumno("MARGARITA SANCHEZ LOPEZ","Ingenieria Industrial","23TE020123","yzab1121WXY543210", 39, 41);
        a[20] = new Alumno("ISIDRO GARCIA RIVERA","Ingenieria Industrial","23TE021234","cdef3141ZAB321987", 33, 47);
        a[21] = new Alumno("NANCY FERNANDEZ LOPEZ","Ingenieria Industrial","23TE022345","ghij5161CDE765432", 30, 50);
        a[22] = new Alumno("PEDRO PEREZ GOMEZ","Ingenieria Industrial","23TE023456","klmn7181FGH109876", 31, 49);
        a[23] = new Alumno("MONICA RAMIREZ MARTINEZ","Ingenieria Industrial","23TE024567","mnop9202IJK432109", 28, 52);
        a[24] = new Alumno("PATRICIO LOPEZ SANCHEZ","Ingenieria Industrial","23TE025678","qrst1234LMN098765", 29, 51);
        a[25] = new Alumno("BERENICE PEREZ GOMEZ","Ingenieria Industrial","23TE026789","uvwx5678OPQ765432", 37, 43);
        a[26] = new Alumno("HECTOR GARCIA LOPEZ","Ingenieria Industrial","23TE027890","yzab9101RST543210", 31, 49);
        a[27] = new Alumno("VERONICA LOPEZ FERNANDEZ","Ingenieria Industrial","23TE028901","cdef1121UVW321098", 40, 40);
        a[28] = new Alumno("ALEJANDRO MARTINEZ SANCHEZ","Ingenieria Industrial","23TE029012","ghij3141XYZ987654", 32, 48);
        a[29] = new Alumno("EMILIA PEREZ GARCIA","Ingenieria Industrial","23TE030123","klmn5161ABC432109", 50, 30);
        a[30] = new Alumno("ADRIAN LOPEZ MARTINEZ","Ingenieria Industrial","23TE031234","mnop7181DEF876543", 45, 35);
        a[31] = new Alumno("ROSARIO SANCHEZ HERNANDEZ","Ingenieria Industrial","23TE032345","qrst9202GHI987321", 47, 33);
        a[32] = new Alumno("JAVIER LOPEZ RIVERA","Ingenieria Industrial","23TE033456","uvwx1234JKL654987", 26, 54); 
    }

    public Alumno[] getA() {
        return a;
    }

    public void setA(Alumno[] a) {
        this.a = a;
    }
      
}
