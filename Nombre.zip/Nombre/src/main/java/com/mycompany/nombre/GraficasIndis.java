/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nombre;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author losro
 */
public class GraficasIndis {

    public GraficasIndis() {
    }
    
    public void dibujar(int index,Graphics g,int asis, int inasi,String Nom){
       g.drawLine(80, 400, 400, 400);
       g.drawLine(80, 400, 80, 100);
       int x; int y;
       x=400-((asis*300)/80);
       y=400-((inasi*300)/80);
       g.setColor(Color.GREEN);
       g.fillRect(100,x, 100, 400-x);
       g.setColor(new Color(130,131,130));
       g.fillRect(250,y, 100, 400-y);
       g.setColor(Color.black);
       g.drawRect(100,x, 100, 400-x);
       g.drawRect(250,y, 100, 400-y);
       int a =(asis*100)/80;
       int b =(inasi*100)/80;
       String z = (a + "%");
       String k = (b + "%");
        g.drawString(z, 138, x-10);
        g.drawString(k, 290, y-10);
        g.drawString("Asistencias", 120, 420);
        g.drawString("Faltas", 280, 420);
        g.drawString("0%", 55, 400);
        g.drawString("100%", 40, 110);
        g.drawString(Nom, 25, 50);
        
        g.drawString(String.valueOf(asis), 110, x+15);
        g.drawString(String.valueOf(inasi), 260, y+15);
        
        
        
    }
}
