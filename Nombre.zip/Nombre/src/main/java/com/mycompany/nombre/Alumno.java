/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nombre;

/**
 *
 * @author losro
 */
public class Alumno {
    private String Nombre;
    private String Carrera;
    private String numControl;
    private String Clave;
    private int asistencias;
    private int inasistencias;

    public Alumno(String Nombre, String Carrera, String numControl, String Clave, int inasistencias, int asistencias) {
        this.Nombre = Nombre;
        this.Carrera = Carrera;
        this.numControl = numControl;
        this.Clave = Clave;
        this.inasistencias = inasistencias;
        this.asistencias = asistencias;   
    }

    public String getNombre() {
        return Nombre;
    }

    public String getCarrera() {
        return Carrera;
    }

    public String getNumControl() {
        return numControl;
    }

    public String getClave() {
        return Clave;
    }

    public int getAsistencias() {
        return asistencias;
    }

    public int getInasistencias() {
        return inasistencias;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public void setCarrera(String Carrera) {
        this.Carrera = Carrera;
    }

    public void setNumControl(String numControl) {
        this.numControl = numControl;
    }

    public void setClave(String Clave) {
        this.Clave = Clave;
    }

    public void setAsistencias(int asistencias) {
        this.asistencias = asistencias;
    }

    public void setInasistencias(int inasistencias) {
        this.inasistencias = inasistencias;
    }
    

    
}
