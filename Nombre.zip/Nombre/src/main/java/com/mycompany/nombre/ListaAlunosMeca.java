/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nombre;

/**
 *
 * @author losro
 */
public class ListaAlunosMeca {
    Alumno[] a = new Alumno[33];


    public ListaAlunosMeca() {
        a[0] = new Alumno("JUAN PEREZ HERNANDEZ","Ingenieria Mecatrónica","24TE0012","abcd1234XYZ987654",31, 49);
        a[1] = new Alumno("MARIA LOPEZ GONZALEZ","Ingenieria Mecatrónica","24TE0023","efgh5678ABC321098",20, 60);
        a[2] = new Alumno("CARLOS SANCHEZ MARTINEZ","Ingenieria Mecatrónica","24TE0034","ijkl9101DEF654321",12, 68);
        a[3] = new Alumno("ANA RIVERA FERNANDEZ","Ingenieria Mecatrónica","24TE0045","mnop1121GHI987123",1, 79);
        a[4] = new Alumno("JOSE GOMEZ RAMIREZ","Ingenieria Mecatrónica","24TE0056","qrst3141JKL345678",30, 50);
        a[5] = new Alumno("LUISA MARTINEZ PEREZ","Ingenieria Mecatrónica","24TE0067","uvwx5161MNO432109",10, 70);
        a[6] = new Alumno("FERNANDO GARCIA LOPEZ","Ingenieria Mecatrónica","24TE0078","yzab7181PQR789012",0,80);
        a[7] = new Alumno("PATRICIA HERNANDEZ SANCHEZ","Ingenieria Mecatrónica","24TE0089","cdef9202STU654987",0,80);
        a[8] = new Alumno("ALBERTO LOPEZ MARTINEZ","Ingenieria Mecatrónica","24TE0090","ghij1234VWX321765",12, 68);
        a[9] = new Alumno("SANDRA RAMIREZ RIVERA","Ingenieria Mecatrónica","24TE0101","klmn5678YZA109876",18, 62);
        a[10] = new Alumno("DAVID PEREZ SANCHEZ","Ingenieria Mecatrónica","24TE0112","opqr9101BCD987543",20, 60);
        a[11] = new Alumno("MONICA GOMEZ MARTINEZ","Ingenieria Mecatrónica","24TE0123","stuv1121EFG876432",10, 70);
        a[12] = new Alumno("JAVIER MARTINEZ LOPEZ","Ingenieria Mecatrónica","24TE0134","wxyz3141HIJ543109",3,77);
        a[13] = new Alumno("LAURA LOPEZ HERNANDEZ","Ingenieria Mecatrónica","24TE0145","abcd5161KLM876210",70,10);
        a[14] = new Alumno("MIGUEL RIVERA SANCHEZ","Ingenieria Mecatrónica","24TE0156","efgh7181NOP098765",60,10);
        a[15] = new Alumno("SUSANA GOMEZ PEREZ","Ingenieria Mecatrónica","24TE0167","ijkl9202QRS987654",80,0);
        a[16] = new Alumno("RAUL MARTINEZ GARCIA","Ingenieria Mecatrónica","24TE0178","mnop1234TUV654321",23,57);
        a[17] = new Alumno("NANCY SANCHEZ LOPEZ","Ingenieria Mecatrónica","24TE0189","qrst5678WXY321098",14,66);
        a[18] = new Alumno("JORGE PEREZ MARTINEZ","Ingenieria Mecatrónica","24TE0190","uvwx9101ZAB987654",80,0);
        a[19] = new Alumno("ELENA RIVERA LOPEZ","Ingenieria Mecatrónica","24TE0201","yzab1121CDE543210",70,10);
        a[20] = new Alumno("VICTOR GOMEZ SANCHEZ","Ingenieria Mecatrónica","24TE0212","cdef3141FGH321987",10,70);
        a[21] = new Alumno("ANDREA MARTINEZ RIVERA","Ingenieria Mecatrónica","24TE0223","ghij5161IJK765432",15,65);
        a[22] = new Alumno("LUIS LOPEZ GARCIA","Ingenieria Mecatrónica","24TE0234","klmn7181LMN109876",80,0);
        a[23] = new Alumno("KAREN SANCHEZ PEREZ","Ingenieria Mecatrónica","24TE0245","opqr9202OPQ432109",35,65);
        a[24] = new Alumno("OSCAR PEREZ LOPEZ","Ingenieria Mecatrónica","24TE0256","stuv1234RST098765",40,40);
        a[25] = new Alumno("ISABEL RIVERA MARTINEZ","Ingenieria Mecatrónica","24TE0267","wxyz5678UVW765432",20,60);
        a[26] = new Alumno("DANIEL GOMEZ HERNANDEZ","Ingenieria Mecatrónica","24TE0278","abcd9101XYZ543210",33,47);
        a[27] = new Alumno("RITA MARTINEZ LOPEZ","Ingenieria Mecatrónica","24TE0289","efgh1121ABC321098",18, 62);
        a[28] = new Alumno("HECTOR SANCHEZ GARCIA","Ingenieria Mecatrónica","24TE0290","ijkl3141DEF987654",16, 64);
        a[29] = new Alumno("ALMA PEREZ RIVERA","Ingenieria Mecatrónica","24TE0301","mnop5161GHI432109",11, 69);
        a[30] = new Alumno("MANUEL GARCIA LOPEZ","Ingenieria Mecatrónica","24TE0312","qrst7181JKL876543",9, 71);
        a[31] = new Alumno("MARTHA LOPEZ SANCHEZ","Ingenieria Mecatrónica","24TE0323","uvwx9202MNO987321",3, 77);
        a[32] = new Alumno("ROBERTO MARTINEZ GOMEZ","Ingenieria Mecatrónica","24TE0334","yzab1234PQR654987",1,79);   
    }

    public Alumno[] getA() {
        return a;
    }

    public void setA(Alumno[] a) {
        this.a = a;
    }
}
      

