/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nombre;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author hunte
 */
public class Calendario {
    private Graphics g;
    private Alumno[] a;
    private Color c;
    public Calendario() {
    }
    
    public Calendario(Graphics g,Alumno[] a) {
        this.g = g;
        this.g = g;
    }
    
    public void calendario(Alumno[] a){
        Color color = new Color (87,160,107);
        g.setColor(color);
        g.fillRect(400, 100 , 400,322);
        Color color2 = new Color (0,0,0);
        g.setColor(color);
        int suma=0;
        int num;
        int p=1;
        String[] dias={"Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo"};
        for (int j = 100; j < 560; j+=60){ 
            for (int i = 400; i<1000; i+=60){
                
                num = (int)(Math.random()*100)+1;
                if (num>70) {
                    g.setColor(Color.DARK_GRAY);
                    g.fillRect(i, j, 60, 60);
                }
                else {
                g.setColor(color);
                g.fillRect(i, j, 60, 60);
                g.setColor(color);
            } 
            suma=0;
        }
            g.setColor(color2);
            for (int x = 100; x < 560; x+=60){ 
            for (int y = 400; y<1000; y+=60){
                g.drawRect(y, x, 60, 60);
            }
            
        }
        for (int m = 100; m < 400; m+=40){ 
            for (int i = 400; i<800; i+=40){
                
            g.drawString("", 530+suma, 250);
            suma+=100;
        }
        }
        suma=0;
   
        g.setColor(color);
    }
        String[] meses={"Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};
        int numDia=19;
        int contDia=1;
        int contMes=0;
        g.setColor(Color.WHITE);
            for (int k=0; k<8; k++){
            for (int l=0; l<10; l++){
                g.drawString(dias[p-1], 400+suma+10, 50+(k*60)+65);
                g.drawString(""+numDia, 400+suma+20, 50+(k*60)+80);
                g.drawString(meses[contMes], 400+suma+5, 50+(k*60)+95);
                numDia+=1;
                contDia+=1;
                if (contDia==5){
                    numDia=numDia+2;
                    contDia=0;
                }
                if (numDia>=30){
                    numDia=1;
                    contMes+=1;
                }
                p+=1;
                suma+=60;
                if (p==6){
                    p=1;
                }
            }
            suma=0;
        }
    }

    public Graphics getG() {
        return g;
    }

    public void setG(Graphics g) {
        this.g = g;
    }
    
}

