/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nombre;

/**
 *
 * @author losro
 */
public class ListaAlunosAlimentarias {
    Alumno[] a = new Alumno[33];

    public ListaAlunosAlimentarias() {
        a[0] = new Alumno("ANA PEREZ MARTINEZ","Industrias Alimentarias","23IA001234","abcd1234EFGH5678", 45, 35);
        a[1] = new Alumno("JUAN LOPEZ HERNANDEZ","Industrias Alimentarias","23IA002345","ijkl5678MNOP1234", 50, 30);
        a[2] = new Alumno("MARIA GONZALEZ FLORES","Industrias Alimentarias","23IA003456","qrst1234UVWX5678", 55, 25);
        a[3] = new Alumno("CARLOS RAMIREZ SANCHEZ","Industrias Alimentarias","23IA004567","yzab5678CDEF1234", 60, 20);
        a[4] = new Alumno("LUCIA FERNANDEZ GARCIA","Industrias Alimentarias","23IA005678","ghij1234KLMN5678", 65, 15);
        a[5] = new Alumno("MIGUEL SOTO MARTINEZ","Industrias Alimentarias","23IA006789","opqr5678UVWX1234", 70, 10);
        a[6] = new Alumno("ALICIA LOPEZ GUTIERREZ","Industrias Alimentarias","23IA007890","abcd9876EFGH4321", 75, 5);
        a[7] = new Alumno("JORGE PEREZ HERNANDEZ","Industrias Alimentarias","23IA008901","ijkl4321MNOP9876", 46, 34);
        a[8] = new Alumno("PATRICIA SANCHEZ RAMIREZ","Industrias Alimentarias","23IA009012","qrst9876UVWX4321", 51, 29);
        a[9] = new Alumno("ALBERTO MARTINEZ LOPEZ","Industrias Alimentarias","23IA010123","yzab4321CDEF9876", 56, 24);
        a[10] = new Alumno("ELENA GOMEZ GUTIERREZ","Industrias Alimentarias","23IA011234","ghij9876KLMN4321", 61, 19);
        a[11] = new Alumno("RAUL HERNANDEZ MARTINEZ","Industrias Alimentarias","23IA012345","opqr4321UVWX9876", 66, 14);
        a[12] = new Alumno("SANDRA FLORES PEREZ","Industrias Alimentarias","23IA013456","abcd5678EFGH1234", 71, 9);
        a[13] = new Alumno("VICTOR RIVERA LOPEZ","Industrias Alimentarias","23IA014567","ijkl1234MNOP5678", 76, 4);
        a[14] = new Alumno("FERNANDO HERNANDEZ SOTO","Industrias Alimentarias","23IA015678","qrst5678UVWX1234", 47, 33);
        a[15] = new Alumno("MARGARITA LOPEZ GOMEZ","Industrias Alimentarias","23IA016789","yzab1234CDEF5678", 52, 28);
        a[16] = new Alumno("ALEJANDRO GARCIA RIVERA","Industrias Alimentarias","23IA017890","ghij5678KLMN1234", 57, 23);
        a[17] = new Alumno("MARIA PEREZ LOPEZ","Industrias Alimentarias","23IA018901","opqr1234UVWX5678", 62, 18);
        a[18] = new Alumno("JUAN GUTIERREZ RAMIREZ","Industrias Alimentarias","23IA019012","abcd4321EFGH9876", 67, 13);
        a[19] = new Alumno("LUCIA SANCHEZ GONZALEZ","Industrias Alimentarias","23IA020123","ijkl9876MNOP4321", 72, 8);
        a[20] = new Alumno("ANGEL FLORES HERNANDEZ","Industrias Alimentarias","23IA021234","qrst4321UVWX9876", 77, 3);
        a[21] = new Alumno("MONICA GARCIA LOPEZ","Industrias Alimentarias","23IA022345","yzab9876CDEF4321", 48, 32);
        a[22] = new Alumno("ROBERTO LOPEZ GUTIERREZ","Industrias Alimentarias","23IA023456","ghij4321KLMN9876", 53, 27);
        a[23] = new Alumno("ALEJANDRA PEREZ MARTINEZ","Industrias Alimentarias","23IA024567","opqr9876UVWX4321", 58, 22);
        a[24] = new Alumno("JAVIER SOTO GONZALEZ","Industrias Alimentarias","23IA025678","abcd1234EFGH5678", 63, 17);
        a[25] = new Alumno("CECILIA GONZALEZ HERNANDEZ","Industrias Alimentarias","23IA026789","ijkl5678MNOP1234", 68, 12);
        a[26] = new Alumno("MARIO RIVERA MARTINEZ","Industrias Alimentarias","23IA027890","qrst1234UVWX5678", 73, 7);
        a[27] = new Alumno("LUZ FERNANDEZ PEREZ","Industrias Alimentarias","23IA028901","yzab5678CDEF1234", 78, 2);
        a[28] = new Alumno("CRISTINA LOPEZ GUTIERREZ","Industrias Alimentarias","23IA029012","ghij1234KLMN5678", 49, 31);
        a[29] = new Alumno("RAFAEL MARTINEZ SOTO","Industrias Alimentarias","23IA030123","opqr5678UVWX1234", 54, 26);
        a[30] = new Alumno("ISIDRO GARCIA LOPEZ","Industrias Alimentarias","23IA031234","abcd9876EFGH4321", 59, 21);
        a[31] = new Alumno("PAOLA HERNANDEZ MARTINEZ","Industrias Alimentarias","23IA032345","ijkl4321MNOP9876", 64, 16);
        a[32] = new Alumno("ADRIAN RIVERA PEREZ","Industrias Alimentarias","23IA033456","qrst9876UVWX4321", 69, 11);  
    }

    public Alumno[] getA() {
        return a;
    }

    public void setA(Alumno[] a) {
        this.a = a;
    }
      
}
