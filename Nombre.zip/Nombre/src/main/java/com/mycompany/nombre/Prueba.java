/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.nombre;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

/**
 *
 * @author hunte
 */
public class Prueba {
    private Graphics2D g;
    private int x;
    private int y;
    private Color color;
    private Alumno[] a;
    public Prueba() {
    }

    public Prueba(Alumno[] a) {
        
    }

    public Prueba(Graphics2D g, int x, int y,Color color) {
        this.g = g;
        this.x = 1200;
        this.y = 900;
        this.color=color;
    }

    public Prueba(Graphics2D g, Alumno[] a) {
        this.g = g;
        this.a = a;
    }
    
    public void eGrupal(Alumno[] a){
        Graphics2D g2d = (Graphics2D) g;
        AffineTransform originalTransform = g2d.getTransform();
        int nEstudiantes = a.length;
        int estudiante = 650/nEstudiantes;
        int espacio = 100; 
        int espaciox=0;
        int sumay=170;
        int asistencia = 20;
        g.drawLine(450, 600, 1050, 600);
        g.drawLine(450, 600, 450, 140);
        for (int i=asistencia; i>0; i--){
            g.drawLine(450, sumay-20,445 , sumay-20);
            g.drawString("Asistencias: " +asistencia*4, 360, sumay-18);
            asistencia-=1;
            sumay+=22;
        }
        g.rotate(Math.toRadians(180));
        Color col = new Color (87,160,107);
        for (int i=0; i<a.length;i++){
            if (a[a.length-1-i].getAsistencias()<40){
                g.setColor(Color.DARK_GRAY);
            }
            else {
                g.setColor(col);
            }
            g.fillRect(espacio+estudiante-1210+a.length/2, -600,18 ,a[a.length-1-i].getAsistencias()*6-20);
            espacio=espacio+estudiante;
        }
        g.rotate(Math.toRadians(-180));
        g.setColor(Color.BLACK);
        espacio = 100;
        g.rotate(Math.toRadians(-90));
        espacio = 100;
        g.translate(-750, 50);
        int suma = 0;
        int espacio1 = 0;
        Color col2 = new Color (255, 255, 255);
        g.setColor(col2);
        for (int i=0; i<=a.length; i++){
            g.drawString(a[i].getNombre(), espacio-suma-a.length+100, espacio-espacio1+312);
            espacio = espacio + estudiante+20;
            espaciox = espaciox + espacio;
            suma+=39;
            espacio1-=-20;
        }
    }
    
    public Graphics2D getG() {
        return g;
    }
    public void setG(Graphics2D g) {
        this.g = g;
    }
    public int getX() {
        return x;
    }
    public void setX(int x) {
        this.x = x;
    }
    public int getY() {
        return y;
    }
    public void setY(int y) {
        this.y = y;
    }    

    public Alumno[] getA() {
        return a;
    }

    public void setA(Alumno[] a) {
        this.a = a;
    }

    
}
