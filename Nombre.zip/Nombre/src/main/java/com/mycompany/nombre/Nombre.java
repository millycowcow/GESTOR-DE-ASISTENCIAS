/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.nombre;

import java.io.IOException;

/**
 *
 * @author losro
 */
public class Nombre {

    public static void main(String[] args) throws IOException {
        System.out.println("Hello World!");
        ListaAlunosInfo h = new ListaAlunosInfo();
        Reportes xd = new Reportes();
        xd.generar_reportes(h.getA(),"Info");
    }
}
