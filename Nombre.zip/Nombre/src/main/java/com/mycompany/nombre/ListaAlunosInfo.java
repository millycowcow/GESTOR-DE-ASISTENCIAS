/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nombre;

/**
 *
 * @author losro
 */
public class ListaAlunosInfo {
    Alumno[] a = new Alumno[33];

    public ListaAlunosInfo() {
        a[0] = new Alumno("ALBERTO MARTINEZ OSWALDO","Ingenieria Informatica","23TE0046","iolkmjygf", 40, 40);
        a[1] = new Alumno("AMBROSIO LOZADA FRANCISCO MANUEL","Ingenieria Informatica","23TE0028","ueytwmncf", 50, 30);
        a[2] = new Alumno("BELLO RAMIREZ JOSE JULIAN","Ingenieria Informatica","23TE0039","qwmklopñw", 45, 35);
        a[3] = new Alumno("BELLO PEREZ JOSEPH","Ingenieria Informatica","23TE0021","twytewety", 55, 25);
        a[4] = new Alumno("BENAVIDES GUZMAN JESUS","Ingenieria Informatica","23TE0016","jxusnxaio", 20, 60);
        a[5] = new Alumno("CAMACHO ROMAN HERNAND","Ingenieria Informatica","23TE0018","qbutuiopo", 35, 45);
        a[6] = new Alumno("CASTRO APARICIO URIEL ANTONIO","Ingenieria Informatica","23TE0036","jsolkimnt", 50, 30);
        a[7] = new Alumno("CASTRO MORA DANIEL","Ingenieria Informatica","23TE0017","oikplmcrd", 55, 25);
        a[8] = new Alumno("DE GAONA HERNANDEZ VICTOR MANUEL","Ingenieria Informatica","23TE0069","oopwtdnmka", 45, 35);
        a[9] = new Alumno("DE JESUS DOMINGUEZ JUAN PABLO","Ingenieria Informatica","23TE0020","hdnxjsoms", 25, 55);
        a[10] = new Alumno("DE GAONA HERNANDEZ VICTOR MANUEL","Ingenieria Informatica","23TE0069","mknjalsopi", 30, 50);
        a[11] = new Alumno("ESTUDILLO CAMPOS ALDO","Ingenieria Informatica","23TE0041","uwtqnmkip", 40, 40);
        a[12] = new Alumno("FIDEL ALBA EMMANUEL","Ingenieria Informatica","23TE0042","olpirfwde", 35, 45);
        a[13] = new Alumno("HERNANDEZ BELEN MARIA ELENA","Ingenieria Informatica","23TE0048","ujikoedqr", 30, 50);
        a[14] = new Alumno("HERNANDEZ ROJAS ALDAIR","Ingenieria Informatica","23TE0059","TWYHSOKMNJU", 25, 55);
        a[15] = new Alumno("HERNANDEZ SANCHEZ RONALDO","Ingenieria Informatica","23TE0029","jlonmlkij", 20, 60);
        a[16] = new Alumno("HERNANDEZ VELAZQUEZ JORGE","Ingenieria Informatica","23TE0037","ujolikmjy", 50, 30);
        a[17] = new Alumno("ISLAS SALAZAR ANGEL EDUARDO","Ingenieria Informatica","23TE0527","olpñdaeqrty", 40, 40);
        a[18] = new Alumno("JULIAN RAMON MIGUEL ANGEL","Ingenieria Informatica","23TE0035","olpñdaeqrty", 35, 45);
        a[19] = new Alumno("LINO DEL CARMEN YAMILET","Ingenieria Informatica","23TE0031","OLYTAMILE", 55, 25);
        a[20] = new Alumno("LOPEZ GARCIA OSVALDO","Ingenieria Informatica","23TE0019","OEUYJMLOI", 30, 50);
        a[21] = new Alumno("MARTINEZ SANTOS JORGE","Ingenieria Informatica","23TE0024","pñuajmqwn", 45, 35);
        a[22] = new Alumno("MEDINA CANTELLANO JANETH","Ingenieria Informatica","23TE0076","oynmjgvde", 50, 30);
        a[23] = new Alumno("MENDEZ MUÑOZ JOSE MANUEL","Ingenieria Informatica","23TE0037","imvwrghna", 0, 80);
        a[24] = new Alumno("MURRIETA VEGA CESAR","Ingenieria Informatica","23TE0045","pomjfdesa", 40, 40);
        a[25] = new Alumno("LINO DEL CARMEN YAMILET","Ingenieria Informatica","23TE0031","olñpbawgm", 30, 50);
        a[26] = new Alumno("ROJANO DEL CARMEN JESUS","Ingenieria Informatica","23TE0026","olhncrtyu", 55, 25);
        a[27] = new Alumno("SANCHEZ GABRIEL BRAYAN","Ingenieria Informatica","23TE0057","plounjhyf", 50, 30);
        a[28] = new Alumno("SANTIAGO MONFIL EMILIO ALEJANDRO","Ingenieria Informatica","23TE0030","thnvcfrut", 20, 60);
        a[29] = new Alumno("SOLANO ARCE JOSE JAIME","Ingenieria Informatica","23TE0012","ilopñmnhy", 20, 60);
        a[30] = new Alumno("REYES SANCHEZ VICTOR MANUEL","Ingenieria Informatica","23TE0150","opqteuntw", 35, 45);
        a[31] = new Alumno("SANCHEZ GARCIA MARIA JOSE","Ingenieria Informatica","23TE0022","qyinswmje", 25, 55);
        a[32] = new Alumno("VAZQUEZ SANCHEZ OSCAR","Ingenieria Informatica","23TE0058","pñlqwnsju", 80, 0);   
    }

    public Alumno[] getA() {
        return a;
    }

    public void setA(Alumno[] a) {
        this.a = a;
    }
      
}
