/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nombre;

/**
 *
 * @author losro
 */
public class ListaAlunosGestion {
    Alumno[] a = new Alumno[33];

    public ListaAlunosGestion() {
        a[0] = new Alumno("IGNACIO HERNANDEZ LOPEZ","Ingenieria en Gestion Empresarial","23TE001234","abcd5678XYZ432109", 43, 37);
        a[1] = new Alumno("MARIA GARCIA MARTINEZ","Ingenieria en Gestion Empresarial","23TE002345","efgh7890ABC109876", 34, 46);
        a[2] = new Alumno("JUAN PEREZ SANCHEZ","Ingenieria en Gestion Empresarial","23TE003456","ijkl1234DEF987543", 48, 32);
        a[3] = new Alumno("LUISA FLORES RAMIREZ","Ingenieria en Gestion Empresarial","23TE004567","mnop3456GHI876432", 39, 41);
        a[4] = new Alumno("VICTORIA RAMIREZ GOMEZ","Ingenieria en Gestion Empresarial","23TE005678","qrst5678JKL543210", 29, 51);
        a[5] = new Alumno("JORGE MARTINEZ LOPEZ","Ingenieria en Gestion Empresarial","23TE006789","uvwx7890MNO321098", 44, 36);
        a[6] = new Alumno("RAUL GUTIERREZ RIVERA","Ingenieria en Gestion Empresarial","23TE007890","yzab3456PQR109876", 30, 50);
        a[7] = new Alumno("MARTA LOPEZ SANCHEZ","Ingenieria en Gestion Empresarial","23TE008901","cdef5678STU543210", 35, 45);
        a[8] = new Alumno("PABLO FERNANDEZ GONZALEZ","Ingenieria en Gestion Empresarial","23TE009012","ghij7890VWX987123", 40, 40);
        a[9] = new Alumno("CLARA HERNANDEZ MORALES","Ingenieria en Gestion Empresarial","23TE010123","klmn1234YZA876543", 33, 47);
        a[10] = new Alumno("CARLOS GARCIA RUIZ","Ingenieria en Gestion Empresarial","23TE011234","mnop3456BCD765432", 42, 38);
        a[11] = new Alumno("SUSANA PEREZ MARTINEZ","Ingenieria en Gestion Empresarial","23TE012345","qrst5678EFG109876", 31, 49);
        a[12] = new Alumno("ALBERTO LOPEZ LOPEZ","Ingenieria en Gestion Empresarial","23TE013456","uvwx7890HIJ321098", 37, 43);
        a[13] = new Alumno("ISABEL GOMEZ FERNANDEZ","Ingenieria en Gestion Empresarial","23TE014567","yzab3456KLM543210", 34, 46);
        a[14] = new Alumno("MIGUEL RAMIREZ SANCHEZ","Ingenieria en Gestion Empresarial","23TE015678","cdef5678NOP987123", 45, 35);
        a[15] = new Alumno("NATALIA MARTINEZ LOPEZ","Ingenieria en Gestion Empresarial","23TE016789","ghij7890QRS765432", 48, 32);
        a[16] = new Alumno("FERNANDO HERNANDEZ GOMEZ","Ingenieria en Gestion Empresarial","23TE017890","klmn1234TUV109876", 43, 37);
        a[17] = new Alumno("MONICA LOPEZ MARTINEZ","Ingenieria en Gestion Empresarial","23TE018901","mnop3456WXY321098", 32, 48);
        a[18] = new Alumno("DAVID GARCIA PEREZ","Ingenieria en Gestion Empresarial","23TE019012","qrst5678ZAB543210", 39, 41);
        a[19] = new Alumno("VERONICA PEREZ LOPEZ","Ingenieria en Gestion Empresarial","23TE020123","uvwx7890CDE987123", 37, 43);
        a[20] = new Alumno("DIEGO LOPEZ GUTIERREZ","Ingenieria en Gestion Empresarial","23TE021234","yzab3456FGH876543", 34, 46);
        a[21] = new Alumno("PAULA RAMIREZ HERNANDEZ","Ingenieria en Gestion Empresarial","23TE022345","cdef5678IJK109876", 31, 49);
        a[22] = new Alumno("ALEJANDRO MARTINEZ LOPEZ","Ingenieria en Gestion Empresarial","23TE023456","ghij7890LMN321098", 40, 40);
        a[23] = new Alumno("JULIA HERNANDEZ GOMEZ","Ingenieria en Gestion Empresarial","23TE024567","klmn1234OPQ543210", 35, 45);
        a[24] = new Alumno("ENRIQUE LOPEZ FERNANDEZ","Ingenieria en Gestion Empresarial","23TE025678","mnop3456RST987123", 48, 32);
        a[25] = new Alumno("ROSARIO GARCIA LOPEZ","Ingenieria en Gestion Empresarial","23TE026789","qrst5678UVW765432", 33, 47);
        a[26] = new Alumno("HECTOR PEREZ RAMIREZ","Ingenieria en Gestion Empresarial","23TE027890","uvwx7890XYZ109876", 45, 35);
        a[27] = new Alumno("CRISTINA LOPEZ HERNANDEZ","Ingenieria en Gestion Empresarial","23TE028901","yzab3456ABC321098", 34, 46);
        a[28] = new Alumno("MANUEL GOMEZ LOPEZ","Ingenieria en Gestion Empresarial","23TE029012","cdef5678DEF543210", 36, 44);
        a[29] = new Alumno("LILIANA MARTINEZ FERNANDEZ","Ingenieria en Gestion Empresarial","23TE030123","ghij7890GHI987123", 29, 51);
        a[30] = new Alumno("OSCAR LOPEZ SANCHEZ","Ingenieria en Gestion Empresarial","23TE031234","klmn1234JKL876543", 42, 38);
        a[31] = new Alumno("NANCY PEREZ GARCIA","Ingenieria en Gestion Empresarial","23TE032345","mnop3456MNO109876", 43, 37);
        a[32] = new Alumno("JAVIER RAMIREZ MARTINEZ","Ingenieria en Gestion Empresarial","23TE033456","qrst5678PQR321098", 44, 36);  
    }

    public Alumno[] getA() {
        return a;
    }

    public void setA(Alumno[] a) {
        this.a = a;
    }
}

